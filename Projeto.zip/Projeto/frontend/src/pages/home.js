export default function Home() {
  return (
    <div>
      <h1>Frontend de Testes</h1>
      <p>Escolhe uma opção no menu acima.</p>
    </div>
  );
}
