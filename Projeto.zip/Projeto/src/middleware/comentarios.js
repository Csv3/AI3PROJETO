//fazer as permissoes para comentarios
//fazer validação de utillizador ser o autor do comentario