import express from "express";
import {  } from "../controllers/pesquisaController.js";
//import { authMiddleware, authorize } from "../middleware/auth.js";

const router = express.Router();

router.post("/register");


export default router;
